<ul>
    <li><a href="adduser.php">Ajouter utilisateur</a></li>
    <li><a href="updateUser.php">Modifier utilisateur</a></li>
    <li><a href="showUser.php">Afficher Profil</a></li>
</ul>